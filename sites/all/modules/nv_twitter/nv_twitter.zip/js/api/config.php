<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'rddLdIsDrOfppCoWPUQBqxASE');
    define('CONSUMER_SECRET', 'RcOtiq6LsRYPH5CGBpiyNFrs4wkY1hScQuRzHKKWv0QYIv7XC5');

    // User Access Token
    define('ACCESS_TOKEN', '2874219395-SVnZP5WQTxm7SMACz7ThAUSXDMdXGqmmOdBMHdz');
    define('ACCESS_SECRET', '9cOq8vWEyT4KIYO4AT2FnYqDquMnXQF6hcYitvDyP5Fp0');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));